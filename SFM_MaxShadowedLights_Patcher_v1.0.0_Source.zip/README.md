# SFM_MaxShadowedLights_Patcher
 Patcher for Source Filmmaker that enables up to 64 shadowed lights.
